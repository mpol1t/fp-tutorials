-- Informatics 1 - Functional Programming
-- Tutorial 1
--
-- Solutions
--
-- Remember: there are many possible solutions, and if your solution produces
-- the right results, then it is (most likely) correct. However, if your code
-- looks far more complicated than these sample solutions, then you're probably
-- making things too difficult for yourself---try to keep it simple!

import Data.Char
import Data.List
import Test.QuickCheck
import Control.Monad (guard)


-- 1. halveEvens

-- List-comprehension version
halveEvens :: [Int] -> [Int]
halveEvens xs = [ x `div` 2 | x <- xs, x `mod` 2 == 0 ]


-- This is for testing only. Do not try to understand this (yet).
halveEvensReference :: [Int] -> [Int]
halveEvensReference = (>>= \x -> guard (x `mod` 2 == 0) >>= \_ -> return $ x `div` 2)


-- -- Mutual test
prop_halveEvens :: [Int] -> Bool
prop_halveEvens xs = halveEvens xs == halveEvensReference xs


-- 2. inRange

-- List-comprehension version
inRange :: Int -> Int -> [Int] -> [Int]
inRange lo hi xs = [ x | x <- xs, x >= lo, x <= hi ]

prop_inRange :: Int -> Int -> [Int] -> Bool
prop_inRange lo hi xs = and [ not (x < lo) && not (x > hi) | x <- inRange lo hi xs ]


-- 3. countPositives: sum up all the positive numbers in a list

-- List-comprehension version
countPositives :: [Int] -> Int
countPositives xs = length [ x | x <- xs, x > 0 ]


prop_countPositives :: [Int] -> Bool
prop_countPositives xs = countPositives xs == length (filter (\x -> x > 0) xs)

-- 4. pennypincher

-- List-comprehension version.
pennypincher :: [Int] -> Int
pennypincher prices = sum [ discount x | x <- prices, discount x <= 19900 ]
  where
    discount :: Int -> Int
    discount price = round $ (fromIntegral price) * 0.9

-- -- And the test itself
prop_pennypincher :: [Int] -> Bool
prop_pennypincher xs = pennypincher prices <= sum prices
  where
    prices :: [Int]
    prices = filter (\x -> x >= 0) xs



-- 5. multDigits

-- List-comprehension version
multDigits :: String -> Int
multDigits str = product [ digitToInt s | s <- str, isDigit s ]

countDigits :: String -> Int
countDigits str = length [ s | s <- str, isDigit s ]

prop_multDigits :: String -> Bool
prop_multDigits xs = multDigits xs <= 9 ^ (countDigits xs)


-- 6. capitalise

-- List-comprehension version
capitalise :: String -> String
capitalise [] = []
capitalise xs = toUpper (head xs) : [ toLower x | x <- tail xs]

-- 7. title

lowercase :: String -> String
lowercase xs = [ toLower x | x <- xs ]

-- List-comprehension version
title :: [String] -> [String]
title xs = [ if valid idx x then capitalise x else lowercase x | (x, idx) <- zip xs [0..length xs] ]
  where
    valid :: Int -> String -> Bool
    valid 0 _ = True
    valid _ s = length s >= 4


-- 8. signs

sign :: Int -> Char
sign i
  | i >= 1 && i <= 9    = '+'
  | i == 0              = '0'
  | i >= -9 && i <= -1  = '-'
  | otherwise           = error "Invalid input"

signs :: [Int] -> String
signs xs = [ sign x | x <- xs, x >= (-9), x <= 9 ]

-- 9. score

score :: Char -> Int
score x = if isLetter x then 1 + isVowel x + isUpperChar x else 0
  where
    isVowel :: Char -> Int
    isVowel c
      | (toLower c) `elem` ['a', 'e', 'i', 'o', 'u']  = 1
      | otherwise                                     = 0

    isUpperChar :: Char -> Int
    isUpperChar c
      | isUpper c = 1
      | otherwise = 0


totalScore :: String -> Int
totalScore xs = product [ score x | x <- xs, isLetter x]

prop_totalScore_positive :: String -> Bool
prop_totalScore_positive xs = totalScore xs >= 1


-- Optional Material

-- 8. crosswordFind

-- List-comprehension version
crosswordFind :: Char -> Int -> Int -> [String] -> [String]
crosswordFind letter pos len words = [ w | w <- words, length w == len, w !! pos == letter ]


-- 9. search

-- List-comprehension version

search :: String -> Char -> [Int]
search str goal = [ idx | (s, idx) <- zip str [0..length str], s == goal ]

-- Depending on the property you want to test, you might want to change the type signature
prop_search :: String -> Char -> Bool
prop_search str goal = search sanitized goal  == []
  where
    sanitized :: String
    sanitized = [ s | s <- str, s /= goal]


-- 10. contains

contains :: String -> String -> Bool
contains str substr = or [ substr `isPrefixOf` (drop n str) | n <- [0..length str] ]

-- Depending on the property you want to test, you might want to change the type signature
prop_contains :: String -> String -> Bool
prop_contains str1 str2 = contains (str1 ++ str2) str1
