-- Informatics 1 - Functional Programming
-- Tutorial 2
--
-- Solutions
--
-- Remember: there are many possible solutions, and if your solution produces
-- the right results, then it is (most likely) correct. However, if your code
-- looks far more complicated than these sample solutions, then you're probably
-- making things too difficult for yourself---try to keep it simple!
module Tutorial2 where

import Data.Char
import Data.List
import Test.QuickCheck

import Data.Function
import Data.Maybe


-- 1.

halveEvensRec :: [Int] -> [Int]
halveEvensRec [] = []
halveEvensRec (x:xs)
  | x `mod` 2 == 0  = x `div` 2 : halveEvensRec xs
  | otherwise       = halveEvensRec xs

halveEvens :: [Int] -> [Int]
halveEvens xs = [x `div` 2 | x <- xs, x `mod` 2 == 0]

prop_halveEvens :: [Int] -> Bool
prop_halveEvens xs = halveEvensRec xs == halveEvensRec xs


-- 2.

inRangeRec :: Int -> Int -> [Int] -> [Int]
inRangeRec _ _ [] = []
inRangeRec lo hi (x:xs)
  | lo <= x && x <= hi  = x : inRangeRec lo hi xs
  | otherwise           = inRangeRec lo hi xs

inRange :: Int -> Int -> [Int] -> [Int]
inRange lo hi xs = [x | x <- xs, lo <= x, x <= hi]

prop_inRange :: Int -> Int -> [Int] -> Bool
prop_inRange lo hi xs = inRangeRec lo hi xs == inRange lo hi xs


-- 3.

countPositivesRec :: [Int] -> Int
countPositivesRec [] = 0
countPositivesRec (x:xs)
  | x > 0     = 1 + countPositivesRec xs
  | otherwise = countPositivesRec xs

countPositives :: [Int] -> Int
countPositives list = length [x | x <- list, x > 0]

prop_countPositives :: [Int] -> Bool
prop_countPositives xs = countPositivesRec xs == countPositives xs


-- 4.

multDigitsRec :: String -> Int
multDigitsRec [] = 1
multDigitsRec (x:xs)
  | isDigit x   = digitToInt x * multDigitsRec xs
  | otherwise   = multDigitsRec xs

multDigits :: String -> Int
multDigits str = product [digitToInt ch | ch <- str, isDigit ch]

prop_multDigits :: String -> Bool
prop_multDigits str = multDigitsRec str == multDigits str


-- These are some helper functions for makeKey and makeKey itself.
-- Exercises continue below.

rotate :: Int -> [Char] -> [Char]
rotate k list | 0 <= k && k <= length list = drop k list ++ take k list
              | otherwise = error "Argument to rotate too large or too small"

--  prop_rotate rotates a list of lenght l first an arbitrary number m times,
--  and then rotates it l-m times; together (m + l - m = l) it rotates it all
--  the way round, back to the original list
--
--  to avoid errors with 'rotate', m should be between 0 and l; to get m
--  from a random number k we use k `mod` l (but then l can't be 0,
--  since you can't divide by 0)
prop_rotate :: Int -> String -> Bool
prop_rotate k str = rotate (l - m) (rotate m str) == str
                        where l = length str
                              m = if l == 0 then 0 else k `mod` l

alphabet = ['A'..'Z']

makeKey :: Int -> [(Char, Char)]
makeKey k = zip alphabet (rotate k alphabet)

-- Ceasar Cipher Exercises
-- =======================


-- 5.
lookUp :: Char -> [(Char, Char)] -> Char
lookUp target keys = if length filtered > 0 then snd $ head filtered else target
  where
    filtered :: [(Char, Char)]
    filtered = [ k | k <- keys, fst k == target ]

lookUpRec :: Char -> [(Char, Char)] -> Char
lookUpRec target [] = target
lookUpRec target (x:xs)
  | fst x == target = snd x
  | otherwise       = lookUpRec target xs

prop_lookUp :: Char -> [(Char, Char)] -> Bool
prop_lookUp c k = lookUp c k == lookUpRec c k


-- 6.

encipher :: Int -> Char -> Char
encipher key letter = lookUpRec letter (makeKey key)

encipherWithKeys :: Char -> [(Char, Char)] -> Char
encipherWithKeys letter keys = lookUpRec letter keys


-- 7.

normalize :: String -> String
normalize str = [ toUpper s | s <- str, isAlphaNum s ]


-- 8.

encipherStr :: Int -> String -> String
encipherStr key str = [ encipherWithKeys s keys | s <- normalize str ]
  where
    keys :: [(Char, Char)]
    keys = makeKey key


-- Optional Material
-- =================

-- 9.

reverseKey :: [(Char, Char)] -> [(Char, Char)]
reverseKey keys = [ (y, x) | (x, y) <- keys ]

reverseKeyRec :: [(Char, Char)] -> [(Char, Char)]
reverseKeyRec [] = []
reverseKeyRec ((x, y):xs) = (y, x) : reverseKeyRec xs

prop_reverseKey :: [(Char, Char)] -> Bool
prop_reverseKey keys = reverseKey keys == reverseKeyRec keys


-- 10.

decipher :: Int -> Char -> Char
decipher key letter = lookUpRec letter (reverseKeyRec $ makeKey key)

decipherWithKeys :: [(Char, Char)] -> Char -> Char
decipherWithKeys keys letter = lookUpRec letter (reverseKeyRec keys)

decipherStr :: Int -> String -> String
decipherStr _ [] = []
decipherStr key (x:xs)
  | isDigit x || isSpace x  = x : decipherStr key xs
  | isUpper x               = decipherWithKeys keys x : decipherStr key xs
  | otherwise               = decipherStr key xs
    where
      keys :: [(Char, Char)]
      keys = makeKey key


-- 11.

contains :: String -> String -> Bool
contains [] _ = False
contains str substring
  | substring `isPrefixOf` str  = True
  | otherwise                   = contains (tailSafe str) substring

tailSafe :: [a] -> [a]
tailSafe [] = []
tailSafe (x:xs) = xs


-- 12.

candidates :: String -> [(Int, String)]
candidates ciphertext = candidatesAux [ (key, decipherStr key ciphertext) | key <- [0..26] ]
  where
    candidatesAux :: [(Int, String)] -> [(Int, String)]
    candidatesAux [] = []
    candidatesAux (x:xs)
      | contains (snd x) "AND" || contains (snd x) "THE"  = x : candidatesAux xs
      | otherwise                                         = candidatesAux xs

-- 13.

splitEachFive :: String -> [String]
splitEachFive str = splitEachN 5 str

splitEachN :: Int -> String -> [String]
splitEachN _ [] = []
splitEachN n xs
  | l < n     = [xs ++ (replicate (n - l) 'X')]
  | otherwise = take n xs : splitEachN n (drop n xs)
    where
      l = length xs

-- 14.

prop_transpose :: String -> Bool
prop_transpose xs = (transpose $ transpose splitted) == splitted
  where
    splitted = splitEachFive xs


-- 15.

encrypt :: Int -> String -> String
encrypt key cleartext = concat $ transpose $ splitEachFive $ encipherStr key cleartext


-- 16.

decrypt :: Int -> String -> String
decrypt key ciphertext = decipherStr key (concat $ transpose $ splitEachN (length ciphertext `div` 5) ciphertext)
