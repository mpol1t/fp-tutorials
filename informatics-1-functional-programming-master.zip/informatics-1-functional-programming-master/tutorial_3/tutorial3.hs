-- Informatics 1 - Functional Programming
-- Tutorial 3
--
-- Week 5 - Due: 19-20 Oct.
module Tutorial3 where

import Data.Char
import Test.QuickCheck
import Data.List (transpose)


-- 1. Map
-- a.
uppers :: String -> String
uppers str = map toUpper str

-- b.
doubles :: [Int] -> [Int]
doubles xs = map (\x -> x * 2) xs

-- c.
penceToPounds :: [Int] -> [Float]
penceToPounds xs = map (\x -> (fromIntegral x) / 100) xs

-- d.
uppers' :: String -> String
uppers' xs = [ toUpper x | x <- xs ]

prop_uppers :: String -> Bool
prop_uppers str = uppers str == uppers' str



-- 2. Filter
-- a.
alphas :: String -> String
alphas str = filter isAlpha str

-- b.
rmChar ::  Char -> String -> String
rmChar c str = filter (\x -> x /= c) str

-- c.
above :: Int -> [Int] -> [Int]
above lo xs = filter (\x -> x >= lo) xs

-- d.
unequals :: [(Int,Int)] -> [(Int,Int)]
unequals xs = filter (\(x, y) -> x /= y) xs

-- e.
rmCharComp :: Char -> String -> String
rmCharComp c str = [ s | s <- str, s /= c ]

prop_rmChar :: Char -> String -> Bool
prop_rmChar c str = rmChar c str == rmCharComp c str



-- 3. Comprehensions vs. map & filter
-- a.
upperChars :: String -> String
upperChars s = [toUpper c | c <- s, isAlpha c]

upperChars' :: String -> String
upperChars' str = map toUpper (filter isAlpha str)

prop_upperChars :: String -> Bool
prop_upperChars s = upperChars s == upperChars' s

-- b.
largeDoubles :: [Int] -> [Int]
largeDoubles xs = [2 * x | x <- xs, x > 3]

largeDoubles' :: [Int] -> [Int]
largeDoubles' xs = map (\x -> x * 2) (filter (\x -> x > 3) xs)

prop_largeDoubles :: [Int] -> Bool
prop_largeDoubles xs = largeDoubles xs == largeDoubles' xs

-- c.
reverseEven :: [String] -> [String]
reverseEven strs = [reverse s | s <- strs, even (length s)]

reverseEven' :: [String] -> [String]
reverseEven' xs = map reverse (filter (\x -> even $ length x) xs)

prop_reverseEven :: [String] -> Bool
prop_reverseEven strs = reverseEven strs == reverseEven' strs



-- 4. Foldr
-- a.
productRec :: [Int] -> Int
productRec []     = 1
productRec (x:xs) = x * productRec xs

productFold :: [Int] -> Int
productFold xs = foldr (*) 1 xs

prop_product :: [Int] -> Bool
prop_product xs = productRec xs == productFold xs

-- b.
andRec :: [Bool] -> Bool
andRec [] = True
andRec (x:xs) = x && andRec xs

andFold :: [Bool] -> Bool
andFold xs = foldr (&&) True xs

prop_and :: [Bool] -> Bool
prop_and xs = andRec xs == andFold xs

-- c.
concatRec :: [[a]] -> [a]
concatRec [] = []
concatRec (x:xs) = x ++ concatRec xs

concatFold :: [[a]] -> [a]
concatFold xs = foldr (++) [] xs

prop_concat :: [String] -> Bool
prop_concat strs = concatRec strs == concatFold strs

-- d.
rmCharsRec :: String -> String -> String
rmCharsRec [] s = s
rmCharsRec (x:xs) str = rmCharsRec xs (rmChar x str)

rmCharsFold :: String -> String -> String
rmCharsFold xs str = foldr (\x -> rmChar x) str xs

prop_rmChars :: String -> String -> Bool
prop_rmChars chars str = rmCharsRec chars str == rmCharsFold chars str



type Matrix = [[Int]]

-- 5
-- a.
uniform :: [Int] -> Bool
uniform [] = True
uniform (x:xs) = all (\y -> x == y) xs

-- b.
valid :: Matrix -> Bool
valid []    = False
valid [[]]  = False
valid xs    = uniform (map length xs)

zipWith' :: (a -> b -> c) -> [a] -> [b] -> [c]
zipWith' f xs ys = [ f x  y | (x, y) <- zip xs ys ]

zipWith'' :: (a -> b -> c) -> [a] -> [b] -> [c]
zipWith'' f xs ys = map (uncurry f) (zip xs ys)

-- 6.

-- 7.
plusM :: Matrix -> Matrix -> Matrix
plusM a b
  | valid a && valid b && sameShape a b   = zipWith plusRow a b
  | otherwise                             = error "Invalid input"
  where
    sameShape :: Matrix -> Matrix -> Bool
    sameShape a b = shape a == shape b

    plusRow :: [Int] -> [Int] -> [Int]
    plusRow x y = zipWith (+) x y


shape :: Matrix -> (Int, Int)
shape mat = (length mat, length (headSafe mat))
  where
    headSafe :: Matrix -> [Int]
    headSafe []     = []
    headSafe (x:xs) = x

-- 8.
timesM :: Matrix -> Matrix -> Matrix
timesM a b
  | valid     = [ [ dot x y | y <- bT ] | x <- a ]
  | otherwise = error "Invalid dimensionality"
    where
      bT :: Matrix
      bT = transpose b

      dot :: [Int] -> [Int] -> Int
      dot x y = sum $ zipWith (*) x y

      valid :: Bool
      valid = snd shapeA == fst shapeBT
        where
          shapeA  = shape a
          shapeBT = shape bT

-- Optional material
-- 9.

type RationalVector = [Rational]
type RationalMatrix = [RationalVector]

toRMatrix :: Matrix -> RationalMatrix
toRMatrix a = map (map (\x -> toRational x)) a

det :: RationalMatrix -> Rational
det [[a, b], [c, d]] = a * d - b * c
det a                = sum [ (-1) ^ (1 + j) * x * (detA_1j (j - 1)) | (x, j) <- zip (head a) [1..length a] ]
  where
    detA_1j :: Int -> Rational
    detA_1j j = det minor
      where
        minor :: RationalMatrix
        minor = map (\x -> (take j x) ++ (drop (j + 1) x)) (tail a)

identity :: Int -> RationalMatrix
identity n = [ [ if i == j then 1 else 0 | j <- [0..(n - 1)] ] | i <- [0..(n - 1)] ]

inverse :: RationalMatrix -> RationalMatrix
inverse m = undefined


-- Extra
newtype RMatrix = RMatrix [[Rational]]

values :: RMatrix -> [[Rational]]
values (RMatrix xs) = xs

instance Show RMatrix where
  show m = showAux (values m)
    where
      showAux :: [[Rational]] -> String
      showAux []      = ""
      showAux [x]     = vectorStr x
      showAux (x:xs)  = vectorStr x ++ "\n" ++ showAux xs

      vectorStr :: [Rational] -> String
      vectorStr s = "|  " ++ (concat $ [ show x ++ "  " | x <- s]) ++ "|"

instance Eq RMatrix where
  (==) a b = (values a) ==  (values b)

transposeRMatrix :: RMatrix -> RMatrix
transposeRMatrix m = RMatrix (transpose $ values m)
